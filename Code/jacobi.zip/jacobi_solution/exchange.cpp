#include "mpi.h"
#include "jacobi.h"

void Exchange(Mesh *mesh)
{
    double *xlocal = mesh->xlocal;
    int maxm = mesh->maxm;
    int lrow = mesh->lrow;
    int up_nbr = mesh->up_nbr;
    int down_nbr = mesh->down_nbr;

    MPI_Status statuses[4];
    MPI_Request r[4];

    /* Send up, then receive from below */

    /* Relevant pointers
    * Process rank below: down_nbr (value is -1 if invalid)
    * Process rank above: up_nbr (value is -1 if invalid)
    * Receive from below:   xlocal
    * Send to below:        xlocal + maxm
    * Receive from above:   xlocal + maxm * (lrow + 1)
    * Send to above:        xlocal + maxm * lrow
    * Size of data: maxm
    */
    if (down_nbr >= 0)
    {
        MPI_Irecv(xlocal, maxm, MPI_DOUBLE, down_nbr,
                  MPI_ANY_TAG, MPI_COMM_WORLD, &r[0]);
        MPI_Isend(xlocal + maxm, maxm, MPI_DOUBLE, down_nbr,
                  0, MPI_COMM_WORLD, &r[1]);
    }

    if (up_nbr >= 0)
    {
        MPI_Irecv(xlocal + maxm * (lrow + 1), maxm, MPI_DOUBLE, up_nbr,
                  MPI_ANY_TAG, MPI_COMM_WORLD, &r[2]);
        MPI_Isend(xlocal + maxm * lrow, maxm, MPI_DOUBLE, up_nbr,
                  0, MPI_COMM_WORLD, &r[3]);
    }

    if (down_nbr >= 0)
    {
        MPI_Waitall(2, r, statuses);
    }

    if (up_nbr >= 0)
    {
        MPI_Waitall(2, r + 2, statuses + 2);
    }
}