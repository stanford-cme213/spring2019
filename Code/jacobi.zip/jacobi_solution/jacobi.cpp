#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cassert>
#include "mpi.h"
#include "jacobi.h"

char TESTNAME[] = "MPI_Jacobi";

void Get_command_line(int rank, int argc, char **argv, int *maxm, int *maxn, int *do_print, int *maxit);
void Init_mesh(Mesh *mesh);
void Setup_mesh(int maxm, int maxn, Mesh *mesh);
void Exchange(Mesh *mesh);

// do_print: controls output useful for debugging
static int do_print = 0;
static int max_it = 100;

double fixed_point_from_dbl(double x)
{
    const double truncate = 1.0;
    // This value can be adjusted.
    // Increase truncate to zero out more digits.
    const double half = 0.5;
    double temp = x / truncate;
    temp += (x >= 0.0) ? half : -half;
    temp = truncate * ((temp >= 0) ? temp - half : temp + half);
    return temp;
}

int main(int argc, char **argv)
{
    int rank, size;
    int maxm, maxn, lrow;

    MPI_Init(&argc, &argv);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    Get_command_line(rank, argc, argv, &maxm, &maxn, &do_print, &max_it);

    Mesh mesh;
    Setup_mesh(maxm, maxn, &mesh);

    int itcnt = 0;

    Init_mesh(&mesh);
    MPI_Barrier(MPI_COMM_WORLD);
    double t = MPI_Wtime();
    if (do_print && rank == 0)
    {
        printf("Starting at time %f\n", t);
        fflush(stdout);
    }

    double gdiffnorm;
    double *xlocalrow, *xnewrow;

    /* lrow is used enough that we make a local copy */
    lrow = mesh.lrow;

    do
    {
        Exchange(&mesh);

        // Compute new values (but not on boundary).
        itcnt++;

        double diffnorm = 0.0;

        xnewrow = mesh.xnew + 1 * maxm;
        xlocalrow = mesh.xlocal + 1 * maxm;
        for (int i = 1; i <= lrow; i++, xnewrow += maxm, xlocalrow += maxm)
        {
            for (int j = 1; j < maxm - 1; j++)
            {
                /* Multiply by .25 instead of divide by 4.0 */
                xnewrow[j] = (xlocalrow[j + 1] +
                              xlocalrow[j - 1] +
                              xlocalrow[maxm + j] +
                              xlocalrow[-maxm + j]) *
                             0.25;

                double diff = xnewrow[j] - xlocalrow[j];
                diff = fixed_point_from_dbl(diff * diff);
                diffnorm += diff;
            }
        }

        double *swap = mesh.xlocal;
        mesh.xlocal = mesh.xnew;
        mesh.xnew = swap;

        /* Convergence test */
        gdiffnorm = 0.;
        // Avoiding round off errors in addition
        MPI_Allreduce(&diffnorm, &gdiffnorm, 1, MPI_DOUBLE, MPI_SUM,
                      MPI_COMM_WORLD);
        if (size == 1)
            gdiffnorm = diffnorm;

        assert(gdiffnorm > 0.);

        gdiffnorm = sqrt(gdiffnorm);
        if (do_print && rank == 0 && (itcnt % 100 == 0))
            printf("At iteration %4d, diff = %40.30e\n", itcnt, gdiffnorm);
    } while (gdiffnorm > 1.0e-2 && itcnt < max_it);

    t = MPI_Wtime() - t;

    if (rank == 0)
    {
        /* 4 ops for new value, 3 for norm */
        printf(
            "%s: %d iterations in %f secs (%f MFlops); diffnorm %f, m=%d n=%d np=%d\n",
            TESTNAME, itcnt, t,
            itcnt * (maxm - 2.0) * (maxn - 2) * (4 + 3) * 1.0e-6 / t, gdiffnorm,
            maxm, maxn, size);
    }

    MPI_Finalize();
    return 0;
}