#include "mpi.h"
#include "jacobi.h"

void Exchange(Mesh *mesh)
{
    double *xlocal = mesh->xlocal;
    int maxm = mesh->maxm;
    int lrow = mesh->lrow;
    int up_nbr = mesh->up_nbr;
    int down_nbr = mesh->down_nbr;

    MPI_Status statuses[4];
    MPI_Request r[4];

    /* Send up, then receive from below */

    /* Relevant pointers
    * Process rank below: down_nbr (value is -1 if invalid)
    * Process rank above: up_nbr (value is -1 if invalid)
    * Receive from below:   xlocal
    * Send to below:        xlocal + maxm
    * Receive from above:   xlocal + maxm * (lrow + 1)
    * Send to above:        xlocal + maxm * lrow
    * Size of data: maxm
    */

    // TODO: Irecv; Isend; Waitall
    // Be careful with top and bottom ranks
}